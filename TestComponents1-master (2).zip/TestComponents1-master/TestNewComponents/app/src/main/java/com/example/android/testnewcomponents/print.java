package com.example.android.testnewcomponents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.getbase.floatingactionbutton.FloatingActionButton;

public class print extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_print);
        TextView gen=findViewById(R.id.gen);
        TextView meal=findViewById(R.id.meal);
        TextView name=findViewById(R.id.name);
        TextView email=findViewById(R.id.email);
        TextView num=findViewById(R.id.num);
        TextView agr=findViewById(R.id.agree);
        Button back=findViewById(R.id.back);
        TextView pay=findViewById(R.id.pay);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(print.this,application.class);
                startActivity(intent);
            }
        });


        Bundle b=getIntent().getExtras();
        gen.setText(b.getString("gen"));
        meal.setText(b.getString("meal"));
        name.setText(b.getString("name"));
        email.setText(b.getString("email"));
        num.setText(b.getString("num"));
        agr.setText(b.getString("agree"));
        pay.setText(b.getString("pay"));

    }
}