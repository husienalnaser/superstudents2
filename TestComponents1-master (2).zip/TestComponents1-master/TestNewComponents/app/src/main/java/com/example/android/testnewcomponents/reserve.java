package com.example.android.testnewcomponents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;

public class reserve extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserve);
        final RadioButton male=findViewById(R.id.male);
        final RadioButton female=findViewById(R.id.female);
        final RadioButton breakfast=findViewById(R.id.breakfast);
        final RadioButton lunch=findViewById(R.id.lunch);
        final RadioButton dinner=findViewById(R.id.dinner);
        Button nexto=findViewById(R.id.reservefinal);
        final RadioGroup meal=findViewById(R.id.meal);
        final RadioGroup gen=findViewById(R.id.ad);
        final EditText name=findViewById(R.id.name);
        final EditText email=findViewById(R.id.email);
        final EditText num=findViewById(R.id.num);
        final CheckBox agree=findViewById(R.id.checkBox);
        final Switch pay=findViewById(R.id.pay);


        nexto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int checkmeal=meal.getCheckedRadioButtonId();
                int checgen=gen.getCheckedRadioButtonId();
                Intent intent=new Intent(reserve.this,print.class);
                if(checgen==R.id.male){
                    intent.putExtra("gen",male.getText().toString());
                } else if(checgen==R.id.female){
                    intent.putExtra("gen",female.getText().toString());
                }
                if(checkmeal==R.id.breakfast){
                    intent.putExtra("meal",breakfast.getText().toString());
                } else if(checkmeal==R.id.lunch){
                    intent.putExtra("meal",lunch.getText().toString());
                }else if(checkmeal==R.id.dinner){
                    intent.putExtra("meal",dinner.getText().toString());
                }
                intent.putExtra("name",name.getText().toString());
                intent.putExtra("email",email.getText().toString());
                intent.putExtra("num",num.getText().toString());
                if(agree.isChecked()){
                    intent.putExtra("agree","agreed");
                }else{
                    intent.putExtra("agree","didnt agree");
                }
                if(pay.isChecked()){
                    intent.putExtra("pay","yes");

                }else{
                    intent.putExtra("pay","no");

                }
                startActivity(intent);



            }
        });
    }
}