package com.example.android.testnewcomponents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

public class review extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);
        final SeekBar service=findViewById(R.id.service);
        SeekBar food=findViewById(R.id.food);
        final TextView foodrev=findViewById(R.id.foodrev);
        final TextView servicerev=findViewById(R.id.servicerev);
        Button submit =findViewById(R.id.submit);
        final EditText com=findViewById(R.id.reviewcom);

        food.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if(seekBar.getProgress()<=25){
                    foodrev.setText("bad");
                }
                else if(seekBar.getProgress()<=50){
                    foodrev.setText("meh");
                }
                else if(seekBar.getProgress()<=75){
                    foodrev.setText("goodا");
                }
                else{
                    foodrev.setText("amazing");
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        service.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if(seekBar.getProgress()<=25){
                    servicerev.setText("bad");
                }
                else if(seekBar.getProgress()<=50){
                    servicerev.setText("meh");
                }
                else if(seekBar.getProgress()<=75){
                    servicerev.setText("goodا");
                }
                else{
                    servicerev.setText("amazing");
                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                com.setText("");

//                openDialog();
                Intent intent=new Intent(review.this,application.class);
                startActivity(intent);


            }
        });
    }
    public void openDialog(){
        dialogbox alert=new dialogbox();
        alert.show(getSupportFragmentManager(),"husien");
    }

}